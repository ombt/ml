
select
    dxr.moduleserialnumber as modulesn,
    date_format(max(dxr.datetimestamplocal),'yyyyMMddHHmmss') as flag_date,
    count(dxr.testid) as num_testid,
    max(dxr.integrateddarkcount) as max_idc,
    stddev(dxr.integrateddarkcount) as sd_idc
from
    dx_205_alinity_i_result dxr
where
    to_date('2019-10-23', 'yyyy-MM-dd') <= dxr.datetimestamplocal
and 
    dxr.datetimestamplocal < to_date('2019-10-24', 'yyyy-MM-dd')
and
    dxr.integrateddarkcount is not null
and
    dxr.integrateddarkcount >= 1
and
    upper(dxr.moduleserialnumber) like 'AI%'
group by
    dxr.moduleserialnumber
having
    count(dxr.testid) >= 10
and
    max(dxr.integrateddarkcount) >= 543
and
    stddev(dxr.integrateddarkcount) >= 110
order by
    dxr.moduleserialnumber

select
    distinct(dxr.moduleserialnumber) as modulesn
from
    dx_205_alinity_i_result dxr
where
    to_date('2019-10-23', 'yyyy-MM-dd') <= dxr.datetimestamplocal
and 
    dxr.datetimestamplocal < to_date('2019-10-24', 'yyyy-MM-dd')
